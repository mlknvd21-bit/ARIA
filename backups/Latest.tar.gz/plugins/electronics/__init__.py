from .tool import ElectronicsTool

def load():
    return [ElectronicsTool()]
