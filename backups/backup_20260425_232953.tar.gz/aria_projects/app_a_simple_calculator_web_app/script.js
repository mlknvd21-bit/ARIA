```javascript
let display = document.getElementById('display');
let clearButton = document.getElementById('clear');
let backspaceButton = document.getElementById('backspace');
let divideButton = document.getElementById('divide');
let multiplyButton = document.getElementById('multiply');
let subtractButton = document.getElementById('subtract');
let addButton = document.getElementById('add');
let equalsButton = document.getElementById('equals');
let numberButtons = document.querySelectorAll('#zero, #one, #two, #three, #four, #five, #six, #seven, #eight, #nine');
let decimalButton = document.getElementById('decimal');

let currentNumber = '';
let previousNumber = '';
let operation = '';

numberButtons.forEach(button => {
    button.addEventListener('click', () => {
        currentNumber += button.textContent;
        display.value = currentNumber;
    });
});

decimalButton.addEventListener('click', () => {
    if (!currentNumber.includes('.')) {
        currentNumber += '.';
        display.value = currentNumber;
    }
});

divideButton.addEventListener('click', () => {
    operation = 'divide';
    previousNumber = currentNumber;
    currentNumber = '';
    display.value = '';
});

multiplyButton.addEventListener('click', () => {
    operation = 'multiply';
    previousNumber = currentNumber;
    currentNumber = '';
    display.value = '';
});

subtractButton.addEventListener('click', () => {
    operation = 'subtract';
    previousNumber = currentNumber;
    currentNumber = '';
    display.value = '';
});

addButton.addEventListener('click', () => {
    operation = 'add';
    previousNumber = currentNumber;
    currentNumber = '';
    display.value = '';
});

equalsButton.addEventListener('click', () => {
    let result;
    switch (operation) {
        case 'add':
            result = parseFloat(previousNumber) + parseFloat(currentNumber);
            break;
        case 'subtract':
            result = parseFloat(previousNumber) - parseFloat(currentNumber);
            break;
        case 'multiply':
            result = parseFloat(previousNumber) * parseFloat(currentNumber);
            break;