# app_a_simple_hello_world_page_with_heading_h

a simple hello world page with heading "Hello ARIA" and a button that shows an alert when clicked

Built by ARIA.
