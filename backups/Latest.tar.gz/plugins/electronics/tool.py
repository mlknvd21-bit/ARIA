import json
import os
from tools.base import BaseTool

DATABASE_FILE = os.path.join(os.path.dirname(__file__), "..", "..", "data", "electronics_parts.json")

class ElectronicsTool(BaseTool):
    def __init__(self):
        super().__init__(
            name="electronics_parts",
            description="Search electronics components database. Provides part numbers, alternatives, and specifications."
        )
        self.database = self._load_database()

    def _load_database(self):
        try:
            with open(DATABASE_FILE, "r") as f:
                return json.load(f)
        except Exception:
            return {}

    def execute(self, params: dict) -> str:
        part = params.get("part", "").strip().lower()
        if not part:
            return "[Error] Please specify a part number, e.g., '2N2222' or 'NE555'."

        # Exact match (keys are lowercase)
        if part in self.database:
            return self._format_part(part, self.database[part])

        # Partial match
        suggestions = [k for k in self.database if part in k]
        if suggestions:
            return f"No exact match for '{part}'. Did you mean: {', '.join(suggestions)}?"

        return f"Part '{part}' not found in database. Add it to data/electronics_parts.json"

    def _format_part(self, part: str, data: dict) -> str:
        lines = [f"📦 {part.upper()} ({data.get('type', 'Unknown')})"]
        for key, val in data.items():
            if key == "alternatives":
                lines.append(f"   🔄 Alternatives: {', '.join(val)}")
            elif key == "uses":
                lines.append(f"   ⚙️ Uses: {val}")
            elif key == "type":
                continue
            else:
                lines.append(f"   📋 {key}: {val}")
        return "\n".join(lines)
