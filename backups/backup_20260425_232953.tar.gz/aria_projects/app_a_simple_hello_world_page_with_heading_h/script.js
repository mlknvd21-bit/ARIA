```javascript
document.addEventListener('DOMContentLoaded', function() {
    const helloButton = document.getElementById('hello-button');
    
    helloButton.addEventListener('click', function() {
        alert('Hello ARIA!');
    });
});
```