import json
import os
import re
from tools.base import BaseTool

DATA_DIR = os.path.join(os.path.dirname(__file__), "data")

class QuranHadithTool(BaseTool):
    def __init__(self):
        super().__init__(
            name="quran_hadith_tool",
            description="Complete Quran & Hadith search: surah, ayah, book, number, text search."
        )
        self.quran = self._load_quran()
        self.hadith = self._load_hadith()

    def _load_quran(self):
        """Try to load from quran_ur.json, fallback to quran_data.json."""
        for fname in ["quran_ur.json", "quran_data.json"]:
            path = os.path.join(DATA_DIR, fname)
            if os.path.isfile(path):
                with open(path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                # Normalize: convert whatever structure to {surah_num: {name, ayahs: [{number, arabic, urdu, en}]}}
                return self._normalize_quran(data)
        return {}

    def _normalize_quran(self, raw):
        """Normalize various Quran JSON formats to a uniform structure."""
        normalized = {}
        if isinstance(raw, list):
            # Format: [{id:1, name:"الفاتحة", verses:[...]}] or [{surah:1, ayahs:[...]}]
            for item in raw:
                surah_num = str(item.get("id") or item.get("surah") or item.get("number", ""))
                ayahs = item.get("verses") or item.get("ayahs") or item.get("ayat") or []
                normalized[surah_num] = {
                    "name_en": item.get("transliteration") or item.get("name_en") or item.get("name", ""),
                    "name_ar": item.get("name") or item.get("name_ar", ""),
                    "ayahs": []
                }
                for a in ayahs:
                    normalized[surah_num]["ayahs"].append({
                        "number": a.get("number") or a.get("num") or a.get("id", ""),
                        "arabic": a.get("text") or a.get("arabic") or a.get("ar") or "",
                        "urdu": a.get("urdu") or a.get("translation_ur") or a.get("ur") or "",
                        "en": a.get("en") or a.get("translation_en") or a.get("english") or ""
                    })
        elif isinstance(raw, dict):
            # Format: {"1": {name_en, name_ar, ayahs:[...]}} or {"surahs": [...]}
            surahs = raw.get("surahs") or raw.get("surah") or raw.get("data")
            if surahs:
                return self._normalize_quran(surahs)
            # Assume key is surah number
            for key, val in raw.items():
                if isinstance(val, dict):
                    ayahs = val.get("ayahs") or val.get("verses") or val.get("ayat") or val.get("verse") or []
                    normalized[key] = {
                        "name_en": val.get("name_en") or val.get("transliteration") or val.get("name", ""),
                        "name_ar": val.get("name_ar") or val.get("name", ""),
                        "ayahs": []
                    }
                    for a in ayahs:
                        normalized[key]["ayahs"].append({
                            "number": a.get("number") or a.get("num") or a.get("id") or a.get("verse", ""),
                            "arabic": a.get("arabic") or a.get("text") or a.get("ar", ""),
                            "urdu": a.get("urdu") or a.get("translation_ur") or a.get("ur", ""),
                            "en": a.get("en") or a.get("translation_en") or a.get("english", "")
                        })
        return normalized

    def _load_hadith(self):
        """Load hadith from multiple books, fallback to hadith_data.json."""
        books = {}
        # Try to load separate book files
        for book_name, filename in [
            ("بخاری", "hadith_bukhari.json"),
            ("مسلم", "hadith_muslim.json"),
            ("ترمذی", "hadith_tirmidhi.json"),
        ]:
            path = os.path.join(DATA_DIR, filename)
            if os.path.isfile(path):
                with open(path, "r", encoding="utf-8") as f:
                    books[book_name] = json.load(f)
        if not books:
            path = os.path.join(DATA_DIR, "hadith_data.json")
            if os.path.isfile(path):
                with open(path, "r", encoding="utf-8") as f:
                    books = {"small": json.load(f)}
        return books

    def _normalize_arabic(self, text: str) -> str:
        return re.compile(r'[\u064B-\u0652\u0670]').sub('', text)

    def _contains_text(self, haystack: str, needle: str) -> bool:
        return needle in haystack or needle in self._normalize_arabic(haystack)

    # ... (باقی execute, _quran_execute, _hadith_execute, handle_command, get_widget_html وہی رہیں گے)
    # اہم: _format_surah میں کوئی تبدیلی نہیں — وہ پہلے سے درست تھا
    def execute(self, params): 
        action = params.get("action", "").strip().lower()
        if action == "quran": return self._quran_execute(params)
        elif action == "hadith": return self._hadith_execute(params)
        else: return "[Error] Use action='quran' or 'hadith'."

    def _quran_execute(self, params):
        surah = params.get("surah", "").strip()
        ayah_num = params.get("ayah", "").strip()
        search_text = params.get("search", "").strip().lower()
        target = None
        if surah:
            if surah in self.quran: target = self.quran[surah]
            else:
                for s, d in self.quran.items():
                    if surah.lower() in d.get("name_en","").lower() or surah in d.get("name_ar",""):
                        target = d; break
                if not target: return f"[Error] Surah '{surah}' not found."
        if target and ayah_num:
            for a in target.get("ayahs", []):
                if str(a.get("number","")) == ayah_num: return self._fmt_ayah(target, a)
            return f"[Error] Ayah {ayah_num} not found."
        if target: return self._fmt_surah(target)
        if search_text:
            res = []
            for s_d in self.quran.values():
                for a in s_d.get("ayahs", []):
                    if self._contains_text(a.get("arabic",""), search_text) or search_text in a.get("urdu","").lower() or search_text in a.get("en","").lower():
                        res.append((s_d, a))
            if res:
                if len(res)>5: return f"Found {len(res)} matches. First 5:\n\n" + "\n---\n".join([self._fmt_ayah(s,a) for s,a in res[:5]])
                return "\n---\n".join([self._fmt_ayah(s,a) for s,a in res])
            return f"No ayahs found containing '{search_text}'."
        return "[Error] For Quran, provide surah, or surah+ayah, or search text."

    def _fmt_surah(self, s):
        ayahs = s.get("ayahs", [])
        lines = [f"📖 {s.get('name_en','')} ({s.get('name_ar','')}) - {len(ayahs)} Ayahs", ""]
        for a in ayahs[:50]:
            lines.append(f"{a.get('number','')}. {a.get('arabic','')}")
            lines.append(f"   🇵🇰 {a.get('urdu','')}")
            lines.append("")
        if len(ayahs)>50: lines.append(f"... and {len(ayahs)-50} more ayahs.")
        return "\n".join(lines)

    def _fmt_ayah(self, s, a):
        return f"📖 {s.get('name_en','')} ({s.get('name_ar','')}) - Ayah {a.get('number','')}\n   {a.get('arabic','')}\n   🇵🇰 {a.get('urdu','')}\n   🇬🇧 {a.get('en','')}"

    def _hadith_execute(self, params):
        # (وہی حدیث کا کوڈ)
        book = params.get("book", "").strip()
        number = params.get("number", "").strip()
        search_text = params.get("search", "").strip().lower()
        book_map = {"bukhari":"بخاری","muslim":"مسلم","tirmidhi":"ترمذی","tirmizi":"ترمذی","abudaud":"ابو داؤد","nasai":"نسائی","ibnmajah":"ابن ماجہ","muwatta":"مؤطا"}
        mapped = book_map.get(book.lower(), book)
        dataset = None
        if mapped in self.hadith: dataset = self.hadith[mapped]
        else:
            for bname, data in self.hadith.items():
                if mapped in bname: dataset = data; mapped = bname; break
            if dataset is None:
                combined = []
                for bname, data in self.hadith.items():
                    if isinstance(data, list):
                        for h in data: h["book"] = bname; combined.append(h)
                    elif isinstance(data, dict):
                        for k, v in data.items():
                            if isinstance(v, dict): v["book"] = bname; v["number"] = k; combined.append(v)
                dataset = combined
        if isinstance(dataset, dict) and not isinstance(dataset, list): dataset = list(dataset.values())
        filtered = dataset if isinstance(dataset, list) else []
        if number and filtered:
            for h in filtered:
                if str(h.get("number","")) == number: return self._fmt_hadith(h)
            return f"[Error] Hadith number {number} not found."
        if search_text and filtered:
            res = [h for h in filtered if self._contains_text(str(h.get("arabic","")), search_text) or search_text in str(h.get("urdu","")).lower() or search_text in str(h.get("en","")).lower()]
            if res:
                if len(res)>3: return f"Found {len(res)} hadiths. First 3:\n\n" + "\n---\n".join([self._fmt_hadith(r) for r in res[:3]])
                return "\n---\n".join([self._fmt_hadith(r) for r in res])
            return f"No hadith found containing '{search_text}'."
        if filtered and not number and not search_text:
            return "\n---\n".join([self._fmt_hadith(h) for h in filtered[:10]])
        return "[Error] For Hadith, provide book, or book+number, or search text."

    def _fmt_hadith(self, h):
        grade_colors = {"صحیح":"🟢","حسن":"🟡","ضعیف":"🔴"}
        grade = h.get("grade","")
        icon = grade_colors.get(grade,"⚪")
        return f"📜 {h.get('book','?')} #{h.get('number','?')} {icon} {grade}\n   {h.get('arabic','')}\n   🇵🇰 {h.get('urdu','')}\n   🇬🇧 {h.get('en','')}"

    def handle_command(self, command, args):
        parts = args.strip().split(maxsplit=1)
        if command == "/quran":
            sub = parts[0].lower() if parts else ""
            rest = parts[1] if len(parts)>1 else ""
            if sub == "surah": return self._quran_execute({"surah": rest})
            elif sub == "ayah":
                nums = rest.split(":")
                if len(nums)==2: return self._quran_execute({"surah": nums[0], "ayah": nums[1]})
                return "Usage: /quran ayah <surah>:<ayah>"
            elif sub == "search": return self._quran_execute({"search": rest})
            else: return "Usage: /quran [surah|ayah|search] ..."
        elif command == "/hadith":
            sub = parts[0].lower() if parts else ""
            rest = parts[1] if len(parts)>1 else ""
            if sub == "search": return self._hadith_execute({"search": rest})
            else:
                book_name = sub; number = ""
                if rest:
                    rp = rest.strip().split()
                    if rp and rp[0].isdigit(): number = rp[0]
                    else: book_name += " " + rest
                return self._hadith_execute({"book": book_name, "number": number})
        return None

    def get_widget_html(self, widget_name):
        if widget_name == "quran_hadith_widget":
            return """
<div style="display:flex; gap:20px; flex-wrap:wrap;">
    <div style="flex:1; min-width:280px; border:1px solid #ccc; padding:15px; background:#f9f9f9;">
        <h4>📖 Quran Search</h4>
        <select id="quran-action" style="padding:8px; margin:5px 0; width:100%;">
            <option value="surah">By Surah Number</option>
            <option value="ayah">By Surah:Ayah</option>
            <option value="search">Text Search</option>
        </select>
        <input type="text" id="quran-input" placeholder="Enter surah number, e.g. 1" style="padding:8px; margin:5px 0; width:100%;">
        <button onclick="searchQuranWidget()" style="padding:10px 20px; background:#4CAF50; color:white; border:none; cursor:pointer; width:100%;">Search Quran</button>
        <div id="quran-widget-result" style="margin-top:10px; padding:8px; border:1px solid #eee; min-height:50px; max-height:300px; overflow-y:auto; white-space:pre-wrap; background:white;"></div>
    </div>
    <div style="flex:1; min-width:280px; border:1px solid #ccc; padding:15px; background:#f9f9f9;">
        <h4>📜 Hadith Search</h4>
        <select id="hadith-action" style="padding:8px; margin:5px 0; width:100%;">
            <option value="book">By Book & Number</option>
            <option value="search">Text Search</option>
        </select>
        <input type="text" id="hadith-book" placeholder="Book (e.g. bukhari)" style="padding:8px; margin:5px 0; width:100%;">
        <input type="text" id="hadith-number" placeholder="Hadith Number (optional)" style="padding:8px; margin:5px 0; width:100%;">
        <button onclick="searchHadithWidget()" style="padding:10px 20px; background:#4CAF50; color:white; border:none; cursor:pointer; width:100%;">Search Hadith</button>
        <div id="hadith-widget-result" style="margin-top:10px; padding:8px; border:1px solid #eee; min-height:50px; max-height:300px; overflow-y:auto; white-space:pre-wrap; background:white;"></div>
    </div>
</div>

"""
        return ""
